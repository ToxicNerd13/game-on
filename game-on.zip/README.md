# Game On

## How It Works
Search for reviews for your favorite video game! COMING SOON: Users with accounts will be able to save games and leave their own reviews.

## Technologies Used
* HTML5
* CSS3
* Javascript
* jQuery
* Bootstrap 5